<?php echo e($slot); ?>

<?php /**PATH /home/oxgeovvn/systemufpso.edusystems.es/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>