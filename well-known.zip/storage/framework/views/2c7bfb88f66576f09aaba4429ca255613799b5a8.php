<?php echo e($slot); ?>

<?php /**PATH /home/oxgeovvn/login.edusystems.es/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>