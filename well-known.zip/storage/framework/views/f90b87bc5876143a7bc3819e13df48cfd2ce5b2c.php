<h4>1. Terms</h4>

<p>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
    Donec quis lacus porttitor, dignissim nibh sit amet, fermentum felis.
    Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere
    cubilia Curae; In ultricies consectetur viverra. Nullam velit neque,
    placerat condimentum tempus tincidunt, placerat eu lectus. Nam molestie
    porta purus, et pretium risus vehicula in. Cras sem ipsum, varius sagittis
    rhoncus nec, dictum maximus diam. Duis ac laoreet est. In turpis velit, placerat
    eget nisi vitae, dignissim tristique nisl. Curabitur sollicitudin, nunc ut
    viverra interdum, lacus...
</p>

<h4>2. Use License</h4>

<ol type="a">
    <li>
        Aenean vehicula erat eu nisi scelerisque, a mattis purus blandit. Curabitur congue
        ollis nisl malesuada egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit:
    </li>
</ol>

<p>...</p>
<?php /**PATH /home/oxgeovvn/systemufpso.edusystems.es/resources/views/auth/tos.blade.php ENDPATH**/ ?>