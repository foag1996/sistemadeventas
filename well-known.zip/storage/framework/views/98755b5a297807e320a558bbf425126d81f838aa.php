<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/oxgeovvn/Systemufpso.edusystems.es/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>