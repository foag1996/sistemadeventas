<?php $__env->startComponent('mail::message'); ?>

# <?php echo app('translator')->get('Hello!'); ?>

<?php echo app('translator')->get('You are receiving this email because we received a password reset request for your account.'); ?>

<?php $__env->startComponent('mail::button', ['url' => route('password.reset', ['token' => $token])]); ?>
    <?php echo app('translator')->get('Reset Password'); ?>
<?php echo $__env->renderComponent(); ?>

<?php echo app('translator')->get('This password reset link will expire in :count minutes.', [
    'count' => config('auth.passwords.users.expire')
]); ?>


<?php echo app('translator')->get('If you did not request a password reset, no further action is required.'); ?>


<?php echo app('translator')->get('Regards'); ?>,<br>
<?php echo e(setting('app_name')); ?>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/oxgeovvn/login.edusystems.es/resources/views/mail/reset-password.blade.php ENDPATH**/ ?>