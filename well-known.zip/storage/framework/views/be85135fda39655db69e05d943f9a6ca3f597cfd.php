<?php $__env->startComponent('mail::message'); ?>

# <?php echo app('translator')->get('Hello!'); ?>

<?php echo app('translator')->get('New user was just registered on :app website.', ['app' => setting('app_name')]); ?>


<?php echo app('translator')->get('To view the user details just visit the link below.'); ?>


<?php $__env->startComponent('mail::button', ['url' => route('users.show', $user)]); ?>
    <?php echo app('translator')->get('View User'); ?>
<?php echo $__env->renderComponent(); ?>


<?php echo app('translator')->get('Regards'); ?>,<br>
<?php echo e(setting('app_name')); ?>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/oxgeovvn/Systemufpso.edusystems.es/resources/views/mail/user-registered.blade.php ENDPATH**/ ?>