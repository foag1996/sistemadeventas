<?php echo e($slot); ?>

<?php /**PATH /home/oxgeovvn/Systemufpso.edusystems.es/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>