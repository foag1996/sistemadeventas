<?php

namespace Vanguard\Http\Requests\TwoFactor;

class ReSendTwoFactorTokenRequest extends TwoFactorRequest
{
}
